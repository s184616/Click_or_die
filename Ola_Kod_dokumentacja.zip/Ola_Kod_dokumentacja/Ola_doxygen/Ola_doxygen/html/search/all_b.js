var searchData=
[
  ['playerpoints_0',['playerPoints',['../class_click__or__die_1_1_game_window.html#a934fa738acacceeef159d26c129f369b',1,'Click_or_die::GameWindow']]],
  ['pollution_1',['pollution',['../class_click__or__die_1_1_game_window.html#aa736d4b8102ffeb368765823bd0dc9d2',1,'Click_or_die::GameWindow']]],
  ['program_2',['Program',['../class_click__or__die_1_1_program.html',1,'Click_or_die']]]
];
