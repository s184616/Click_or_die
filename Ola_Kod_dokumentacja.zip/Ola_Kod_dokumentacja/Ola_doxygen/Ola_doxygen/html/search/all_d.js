var searchData=
[
  ['shop_0',['Shop',['../class_click__or__die_1_1_shop.html',1,'Click_or_die.Shop'],['../class_click__or__die_1_1_shop.html#a7a38d93d8fdbf78d579c7c0f36763990',1,'Click_or_die.Shop.Shop()']]],
  ['speed_1',['speed',['../class_click__or__die_1_1_shop.html#a1058f2ea1174c2715218e7714da05976',1,'Click_or_die::Shop']]]
];
