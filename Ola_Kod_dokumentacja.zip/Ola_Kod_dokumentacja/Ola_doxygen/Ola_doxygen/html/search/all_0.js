var searchData=
[
  ['_5f20pamount_0',['_20pAmount',['../class_click__or__die_1_1_game_window.html#a31ed4729b4af70641c6e2ed86ef64a7f',1,'Click_or_die::GameWindow']]],
  ['_5f50pamount_1',['_50pAmount',['../class_click__or__die_1_1_game_window.html#aa7936f58eafd846d79488b87f457dcaf',1,'Click_or_die::GameWindow']]],
  ['_5f5pamount_2',['_5pAmount',['../class_click__or__die_1_1_game_window.html#ae48c9dc74613f366242e8c8a7089d75e',1,'Click_or_die::GameWindow']]],
  ['_5fticks_3',['_ticks',['../class_click__or__die_1_1_game_window.html#a8d11c73b6c53679150a6a87d39017b39',1,'Click_or_die::GameWindow']]]
];
