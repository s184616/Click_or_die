var searchData=
[
  ['click_5for_5fdie_0',['Click_or_die',['../namespace_click__or__die.html',1,'']]]
];
