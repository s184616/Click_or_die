var searchData=
[
  ['dispose_0',['Dispose',['../class_click__or__die_1_1_choose_level.html#a990ace6b37353a08bd92ca2aa38f3d55',1,'Click_or_die.ChooseLevel.Dispose()'],['../class_click__or__die_1_1_game_window.html#a2b5e81e969151c9901aaba30376bfbc8',1,'Click_or_die.GameWindow.Dispose()'],['../class_click__or__die_1_1_how_to_play.html#a1ceee2f5d33a18256596fc496b3e9d7f',1,'Click_or_die.HowToPlay.Dispose()'],['../class_click__or__die_1_1_menu.html#a1b80c30cc4ee5512ac12668d3f7d4421',1,'Click_or_die.Menu.Dispose()'],['../class_click__or__die_1_1_shop.html#a1091c76dae7f4a39755c1ee7fe04d4eb',1,'Click_or_die.Shop.Dispose()']]]
];
