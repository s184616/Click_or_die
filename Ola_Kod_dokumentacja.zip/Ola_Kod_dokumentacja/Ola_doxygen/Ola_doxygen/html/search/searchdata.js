var indexSectionsWithContent =
{
  0: "_bcdfghiklmprstv",
  1: "cghmps",
  2: "c",
  3: "bcdfghikmrst",
  4: "_cilmpstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables"
};

