var searchData=
[
  ['speed_0',['speed',['../class_click__or__die_1_1_shop.html#a1058f2ea1174c2715218e7714da05976',1,'Click_or_die::Shop']]]
];
