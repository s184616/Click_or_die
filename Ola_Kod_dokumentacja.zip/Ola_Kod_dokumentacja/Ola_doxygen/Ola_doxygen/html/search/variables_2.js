var searchData=
[
  ['instance_0',['instance',['../class_click__or__die_1_1_choose_level.html#a1047cf5afb3c5314ac7b98fb85e4d677',1,'Click_or_die.ChooseLevel.instance()'],['../class_click__or__die_1_1_game_window.html#ac61fda557df5dac3dffc10d86cc5c15a',1,'Click_or_die.GameWindow.instance()'],['../class_click__or__die_1_1_how_to_play.html#a8b5a2ab6a6dc063310a10b7cefa63d26',1,'Click_or_die.HowToPlay.instance()'],['../class_click__or__die_1_1_menu.html#aa0c650a5ffa2a314d90d07073a820169',1,'Click_or_die.Menu.instance()'],['../class_click__or__die_1_1_shop.html#a90fa193b64fe64b02aba67cabe972753',1,'Click_or_die.Shop.instance()']]]
];
