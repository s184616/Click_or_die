var searchData=
[
  ['value_5fticks_0',['value_ticks',['../class_click__or__die_1_1_game_window.html#a0b3429fac4e7e8c4e91defae7a6bbef3',1,'Click_or_die::GameWindow']]]
];
