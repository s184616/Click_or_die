﻿
namespace Click_or_die
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Shop));
            this.button_return = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.moveTimer = new System.Windows.Forms.Timer(this.components);
            this.pictureBox_potato = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label_money = new System.Windows.Forms.Label();
            this.label_poluttion = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label_pauza = new System.Windows.Forms.Label();
            this.label_ticks = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_potato)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_return
            // 
            this.button_return.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_return.BackgroundImage")));
            this.button_return.Font = new System.Drawing.Font("Calibri", 23.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_return.Location = new System.Drawing.Point(685, 604);
            this.button_return.Name = "button_return";
            this.button_return.Size = new System.Drawing.Size(230, 97);
            this.button_return.TabIndex = 1;
            this.button_return.Text = "Firma - Click or die";
            this.button_return.UseVisualStyleBackColor = true;
            this.button_return.Click += new System.EventHandler(this.button_return_Click);
            this.button_return.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyisdown);
            this.button_return.KeyUp += new System.Windows.Forms.KeyEventHandler(this.keyisup);
            // 
            // button3
            // 
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button3.Location = new System.Drawing.Point(247, 436);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(96, 68);
            this.button3.TabIndex = 2;
            this.button3.Text = "Eko torby";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.Font = new System.Drawing.Font("Calibri", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button4.Location = new System.Drawing.Point(247, 360);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(96, 47);
            this.button4.TabIndex = 3;
            this.button4.Text = "Perlator";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button5.Location = new System.Drawing.Point(24, 261);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(131, 57);
            this.button5.TabIndex = 4;
            this.button5.Text = "Filtr wody";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button6.Location = new System.Drawing.Point(24, 465);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(131, 81);
            this.button6.TabIndex = 5;
            this.button6.Text = "Kosze do segregacji";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button7.Location = new System.Drawing.Point(247, 221);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(96, 37);
            this.button7.TabIndex = 6;
            this.button7.Text = "Listwy";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button8.Location = new System.Drawing.Point(24, 360);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(131, 67);
            this.button8.TabIndex = 7;
            this.button8.Text = "Świetlówki LED";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button9.Location = new System.Drawing.Point(28, 146);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(114, 67);
            this.button9.TabIndex = 8;
            this.button9.Text = "Filtr do komina";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button10.BackgroundImage")));
            this.button10.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button10.Location = new System.Drawing.Point(247, 291);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(96, 41);
            this.button10.TabIndex = 9;
            this.button10.Text = "Rośliny";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button11.BackgroundImage")));
            this.button11.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button11.Location = new System.Drawing.Point(655, 221);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(108, 38);
            this.button11.TabIndex = 10;
            this.button11.Text = "Projekt 1";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button12.BackgroundImage")));
            this.button12.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button12.Location = new System.Drawing.Point(855, 177);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(121, 45);
            this.button12.TabIndex = 11;
            this.button12.Text = "Projekt 2";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button13.BackgroundImage")));
            this.button13.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button13.Location = new System.Drawing.Point(655, 291);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(108, 41);
            this.button13.TabIndex = 12;
            this.button13.Text = "Projekt 3";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button14.BackgroundImage")));
            this.button14.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button14.Location = new System.Drawing.Point(855, 284);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(121, 48);
            this.button14.TabIndex = 13;
            this.button14.Text = "Projekt 4";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // moveTimer
            // 
            this.moveTimer.Enabled = true;
            this.moveTimer.Interval = 10;
            this.moveTimer.Tick += new System.EventHandler(this.moveTimerEvent);
            // 
            // pictureBox_potato
            // 
            this.pictureBox_potato.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox_potato.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox_potato.BackgroundImage")));
            this.pictureBox_potato.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox_potato.Location = new System.Drawing.Point(214, 561);
            this.pictureBox_potato.Name = "pictureBox_potato";
            this.pictureBox_potato.Size = new System.Drawing.Size(57, 84);
            this.pictureBox_potato.TabIndex = 14;
            this.pictureBox_potato.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.SeaShell;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(0, 30);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(291, 310);
            this.textBox1.TabIndex = 15;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox3.BackgroundImage")));
            this.groupBox3.Controls.Add(this.label_money);
            this.groupBox3.Controls.Add(this.label_poluttion);
            this.groupBox3.Location = new System.Drawing.Point(287, 36);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(476, 102);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            // 
            // label_money
            // 
            this.label_money.AutoSize = true;
            this.label_money.BackColor = System.Drawing.Color.Transparent;
            this.label_money.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_money.Location = new System.Drawing.Point(6, 16);
            this.label_money.Name = "label_money";
            this.label_money.Size = new System.Drawing.Size(250, 31);
            this.label_money.TabIndex = 5;
            this.label_money.Text = "Ilość pieniędzy: 0 zł";
            // 
            // label_poluttion
            // 
            this.label_poluttion.AutoSize = true;
            this.label_poluttion.BackColor = System.Drawing.Color.Transparent;
            this.label_poluttion.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_poluttion.Location = new System.Drawing.Point(6, 56);
            this.label_poluttion.Name = "label_poluttion";
            this.label_poluttion.Size = new System.Drawing.Size(444, 31);
            this.label_poluttion.TabIndex = 3;
            this.label_poluttion.Text = "Poziom zanieczyszczenia: 1500 pkt";
            this.label_poluttion.VisibleChanged += new System.EventHandler(this.refresh);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.SeaShell;
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox1.Location = new System.Drawing.Point(363, 206);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(286, 359);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sklep - cennik";
            // 
            // groupBox4
            // 
            this.groupBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox4.BackgroundImage")));
            this.groupBox4.Controls.Add(this.label_ticks);
            this.groupBox4.Controls.Add(this.label_pauza);
            this.groupBox4.Location = new System.Drawing.Point(24, 27);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(168, 71);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            // 
            // label_pauza
            // 
            this.label_pauza.AutoSize = true;
            this.label_pauza.BackColor = System.Drawing.Color.Transparent;
            this.label_pauza.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_pauza.Location = new System.Drawing.Point(13, 38);
            this.label_pauza.Name = "label_pauza";
            this.label_pauza.Size = new System.Drawing.Size(62, 24);
            this.label_pauza.TabIndex = 0;
            this.label_pauza.Text = "Pauza";
            // 
            // label_ticks
            // 
            this.label_ticks.AutoSize = true;
            this.label_ticks.BackColor = System.Drawing.Color.Transparent;
            this.label_ticks.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_ticks.Location = new System.Drawing.Point(12, 13);
            this.label_ticks.Name = "label_ticks";
            this.label_ticks.Size = new System.Drawing.Size(102, 25);
            this.label_ticks.TabIndex = 6;
            this.label_ticks.Text = "Czas: 0 s";
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button_return);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox_potato);
            this.Name = "Shop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shop";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyisdown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.keyisup);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_potato)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button_return;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Timer moveTimer;
        private System.Windows.Forms.PictureBox pictureBox_potato;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label_money;
        private System.Windows.Forms.Label label_poluttion;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label_pauza;
        private System.Windows.Forms.Label label_ticks;
    }
}