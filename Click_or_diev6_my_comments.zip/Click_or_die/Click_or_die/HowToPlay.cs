﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Click_or_die
{
    public partial class HowToPlay : Form
    {
        //zmienna tworząca globalny punkt dostępu do obiektu klasy
        public static HowToPlay instance;

        //inicjalizacja okienka instrukcji gry
        public HowToPlay()
        {
            InitializeComponent();
            instance = this;
        }

        //wyjście z instrukcji gry do menu
        private void button_return_Click(object sender, EventArgs e)
        {
            Menu form_menu = Click_or_die.Menu.instance;
            form_menu.Show();

            HowToPlay form_howtoplay = this;
            form_howtoplay.Close();
        }
    }
}
