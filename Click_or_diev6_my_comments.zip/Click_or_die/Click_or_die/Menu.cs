﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Click_or_die
{
    public partial class Menu : Form
    {
        //zmienna tworząca globalny punkt dostępu do obiektu klasy
        public static Menu instance;

        //inicjalizacja okienka Menu
        public Menu()
        {
            InitializeComponent();
            instance = this;

            // zamykanie przez X w prawym górnym rogu
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
        }

        //funkcja zamykająca aplikacje
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        //rozpoczęcie nowej gry
        private void button_newgame_Click(object sender, EventArgs e)
        {
            //wyświetlenie nowej gry
            GameWindow form_game = GameWindow.instance;
            form_game.Show();

            //wykonanie się restartu
            GameWindow.instance.button_restart_Click(sender, e);

            //zamykanie menu
            Menu form_menu = this;
            form_menu.Hide();
        }

        //wybór poziomu
        private void button_level_Click(object sender, EventArgs e)
        {
            //wyświetlenie okienka wyboru poziomu
            ChooseLevel form_level = new ChooseLevel();
            form_level.Show();

            //zrestartowanie ustawień
            GameWindow.instance.button_restart_Click(sender, e);

            //chowamy menu
            Menu form_menu = this;
            form_menu.Hide();
        }

        //wybór instrukcji gry
        private void button_howtoplay_Click(object sender, EventArgs e)
        {
            //wyświetlenie okienka instrukcji gry
            HowToPlay form_howtoplay = new HowToPlay();
            form_howtoplay.Show();

            //chowamy menu
            Menu form_menu = this;
            form_menu.Hide();
        }

        //przycisk wyjścia z gry
        private void button_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
