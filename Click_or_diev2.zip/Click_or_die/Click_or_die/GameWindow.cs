﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Click_or_die
{
    public partial class GameWindow : Form
    {
        private int playerPoints = 0;
        private int playerMoney = 0; /// dokończyć coś z pieniędzmi
        private int _ticks = 0;
        public Timer t1;
        public Timer t2;
        public int level;
        //public Button b_restart; do usunięcia


        //auto clickers
        int _5pAmount = 0;
        int _20pAmount = 0;
        int _50pAmount = 0;

        //timer value
        int timerCount = 0;

        public static GameWindow instance;

        public GameWindow()
        {
            InitializeComponent();
            instance = this;
            t1 = timer1;
            t2 = COUNTING_TIMER;
            level = 1;
            timer1.Stop();

            // próba ustawienia 1 okienka na menu
            //Menu form_menu = new Menu();
            //form_menu.Show();
            //GameWindow form_game = this;
            //form_game.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
            label_money.Text = "Ilość pieniędzy: " + playerPoints/2 + " zł";
            playerPoints += 1;
            label_poluttion.Text = "Poziom zanieczyszczenia: 1500 pkt";
        }



        private void button_5p_Click(object sender, EventArgs e)
        {
            

            if(playerPoints >= 5)
            {
                _5pAmount += 1;
                playerPoints -= 5;
                label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
                label_money.Text = "Ilość pieniędzy: " + playerPoints/2 + " zł";
                label_coffee.Text = "ilość kawy: " + _5pAmount;
            }
            else
            {
                MessageBox.Show("Masz niewystarczająco punktów!");
            }

        }

        private void button_20p_Click_1(object sender, EventArgs e)
        {
            if (playerPoints >= 20)
            {
                _20pAmount += 1;
                playerPoints -= 20;
                label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
                label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
                label_worker.Text = "ilość pracowników " + _20pAmount;
            }
            else
            {
                MessageBox.Show("Masz niewystarczająco punktów!");
            }
        }

        private void button_50p_Click_1(object sender, EventArgs e)
        {
            if (playerPoints >= 50)
            {
                _50pAmount += 1;
                playerPoints -= 50;
                label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
                label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
                label_firm.Text = "ilość firm: " + _50pAmount;
            }
            else
            {
                MessageBox.Show("Masz niewystarczająco punktów!");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timerCount += 1;

            if (timerCount % 2 == 0)
            {
                playerPoints += _50pAmount;
            }

            if (timerCount % 5 == 0)
            {
                playerPoints += _20pAmount;
            }

            if (timerCount % 10 == 0)
            {
                playerPoints += _5pAmount;
            }

            label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
            label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
            label_poluttion.Text = "Poziom zanieczyszczenia: 1500 pkt";
        }



        public void button_restart_Click(object sender, EventArgs e)
        {
            //Reset button
            timer1.Stop();
            _ticks = 0;
            playerPoints = 0;
            _5pAmount = 0;
            _20pAmount = 0;
            _50pAmount = 0;
            label_ticks.Text = "Czas: 0 s";
            label_coffee.Text = "ilość kawy: " + _5pAmount;
            label_worker.Text = "ilość pracowników " + _20pAmount;
            label_firm.Text = "ilość firm: " + _50pAmount;
        }

        private void COUNTING_TIMER_Tick(object sender, EventArgs e)
        {
            //czasomierz
            _ticks++;
            label_ticks.Text = "Czas: " + _ticks + " s";

            if (_ticks == 400)
            {
                timer1.Stop();
                label_ticks.Text = "Gra skończona";
                label_points.Text = "Ilość kliknięć: " + playerPoints;
                label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
                _ticks = 0;
                playerPoints = 0;
                _5pAmount = 0;
                _20pAmount = 0;
                _50pAmount = 0;
                MessageBox.Show("Czas się skończył!");
            }
        }

        private void button_menu_Click(object sender, EventArgs e)
        {
            GameWindow form_game = this;
            form_game.Hide();

            Menu form_menu = new Menu();
            form_menu.Show();
            button_restart_Click(sender, e);
        }

        private void button_shop_Click(object sender, EventArgs e)
        {
            Shop form_shop = new Shop();
            form_shop.Show();

            timer1.Stop();
            COUNTING_TIMER.Stop();
            GameWindow form_game = this;
            form_game.Hide();
        }
    }
}
