﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Click_or_die
{
    public partial class Shop : Form
    {

        public static Shop instance;

        public Shop()
        {
            InitializeComponent();
            instance = this;
        }

        private void button_return_Click(object sender, EventArgs e)
        {
            //potrzebne
            GameWindow form_game = GameWindow.instance;
            form_game.Show();

            GameWindow.instance.t1.Start();
            GameWindow.instance.t2.Start();

            Shop form_shop = this;
            form_shop.Close();

        }
    }
}
