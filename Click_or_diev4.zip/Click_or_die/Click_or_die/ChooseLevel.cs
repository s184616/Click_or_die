﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Click_or_die
{
    public partial class ChooseLevel : Form
    {

        public static ChooseLevel instance;

        public ChooseLevel()
        {
            InitializeComponent();
            instance = this;

            if (GameWindow.instance.level == 1 )
            {
                button_easy.BackColor = Color.LightCyan;
                button_medium.BackColor = Color.White;
                button_hard.BackColor = Color.White;
                GameWindow.instance.playerPoints = 50 * 2;
                GameWindow.instance.pollution = 1500;
                GameWindow.instance.value_ticks = 500;
                //GameWindow.instance.level_name = "łatwy";
            }

            if (GameWindow.instance.level == 2)
            {
                button_easy.BackColor = Color.White;
                button_medium.BackColor = Color.LightCyan;
                button_hard.BackColor = Color.White;
                GameWindow.instance.playerPoints = 25*2;
                GameWindow.instance.pollution = 2000;
                GameWindow.instance.value_ticks = 600;
                //GameWindow.instance.level_name = "średni";
            }

            if (GameWindow.instance.level == 3)
            {
                button_easy.BackColor = Color.White;
                button_medium.BackColor = Color.White;
                button_hard.BackColor = Color.LightCyan;
                GameWindow.instance.playerPoints = 0;
                GameWindow.instance.pollution = 2500;
                GameWindow.instance.value_ticks = 800;
                //GameWindow.instance.level_name = "trudny";
            }
        }

        private void button_return_Click(object sender, EventArgs e)
        {
            //potrzebne
            Menu form_menu = Click_or_die.Menu.instance;
            form_menu.Show();

            ChooseLevel form_chooselevel = this;
            form_chooselevel.Close();
        }

        private void button_easy_Click(object sender, EventArgs e)
        {
            GameWindow.instance.level = 1;
            button_easy.BackColor = Color.LightCyan;
            button_medium.BackColor = Color.White;
            button_hard.BackColor = Color.White;
        }

        private void button_medium_Click(object sender, EventArgs e)
        {
            GameWindow.instance.level = 2;
            button_easy.BackColor = Color.White;
            button_medium.BackColor = Color.LightCyan;
            button_hard.BackColor = Color.White;
        }

        private void button_hard_Click(object sender, EventArgs e)
        {
            GameWindow.instance.level = 3;
            button_easy.BackColor = Color.White;
            button_medium.BackColor = Color.White;
            button_hard.BackColor = Color.LightCyan;
        }
    }
}
