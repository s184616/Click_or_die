﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Click_or_die
{
    public partial class Menu : Form
    {
        public static Menu instance;

        public Menu()
        {
            InitializeComponent();
            instance = this; //potrzebne

            // zamykanie przez X
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button_newgame_Click(object sender, EventArgs e)
        {
            GameWindow form_game = GameWindow.instance;
            form_game.Show();

            GameWindow.instance.button_restart_Click(sender, e);

            //zamykanie menu
            Menu form_menu = this;
            form_menu.Hide();
        }

        private void button_level_Click(object sender, EventArgs e)
        {
            ChooseLevel form_level = new ChooseLevel();
            form_level.Show();

            GameWindow.instance.button_restart_Click(sender, e);

            //chowamy menu
            Menu form_menu = this;
            form_menu.Hide();
        }

        private void button_howtoplay_Click(object sender, EventArgs e)
        {
            HowToPlay form_howtoplay = new HowToPlay();
            form_howtoplay.Show();

            //chowamy menu
            Menu form_menu = this;
            form_menu.Hide();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
