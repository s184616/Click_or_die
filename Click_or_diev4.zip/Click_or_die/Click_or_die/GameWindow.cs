﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Click_or_die
{
    public partial class GameWindow : Form
    {
        public int playerPoints = 100; //potem zmienić na 0
        public int pollution = 1500; // zanieczyszczenie
        //private int playerMoney = 0; // niewykorzystane do ilości pieniędzy
        //public string level_name = "łatwy"; // niewykorzystane do nazwy levelu
        public int _ticks = 0;
        public int value_ticks = 500;
        public Timer t1;
        public Timer t2;
        public int level;
        //public Button b_restart; do usunięcia


        //auto clickers
        int _5pAmount = 0;
        int _20pAmount = 0;
        int _50pAmount = 0;

        //timer value
        int timerCount = 0;

        public static GameWindow instance;

        public GameWindow()
        {
            InitializeComponent();
            instance = this;
            t1 = timer1;
            t2 = COUNTING_TIMER;
            level = 1;
            timer1.Stop();

            //MessageBox.Show("Ilość czasu wynosi: " + value_ticks + " s, ilość pieniędzy: " + playerMoney/2 + " zł, a zanieczyszczenie: " + pollution + " pkt"); //do testów

            //refresh(); niepotrzebne raczej, do testów

            // próba ustawienia 1 okienka na menu
            //Menu form_menu = new Menu();
            //form_menu.Show();
            //GameWindow form_game = this;
            //form_game.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Ilość czasu wynosi: " + value_ticks + " s, ilość pieniędzy: " + playerMoney / 2 + " zł, a zanieczyszczenie: " + pollution + " pkt"); //do testów
            timer1.Start();
            label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
            label_money.Text = "Ilość pieniędzy: " + playerPoints/2 + " zł";
            playerPoints += 1;
            label_poluttion.Text = "Poziom zanieczyszczenia: "  + pollution.ToString() + " pkt";
        }



        private void button_5p_Click(object sender, EventArgs e)
        {
            

            if(playerPoints >= 5)
            {
                timer1.Start();
                COUNTING_TIMER.Start();
                _5pAmount += 1;
                playerPoints -= 5;
                label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
                label_money.Text = "Ilość pieniędzy: " + playerPoints/2 + " zł";
                label_coffee.Text = "ilość kawy: " + _5pAmount;
            }
            else
            {
                MessageBox.Show("Masz niewystarczająco punktów!");
            }

        }

        private void button_20p_Click_1(object sender, EventArgs e)
        {
            if (playerPoints >= 20)
            {
                timer1.Start();
                COUNTING_TIMER.Start();
                _20pAmount += 1;
                playerPoints -= 20;
                label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
                label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
                label_worker.Text = "ilość pracowników " + _20pAmount;
            }
            else
            {
                MessageBox.Show("Masz niewystarczająco punktów!");
            }
        }

        private void button_50p_Click_1(object sender, EventArgs e)
        {
            if (playerPoints >= 50)
            {
                timer1.Start();
                COUNTING_TIMER.Start();
                _50pAmount += 1;
                playerPoints -= 50;
                label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
                label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
                label_firm.Text = "ilość firm: " + _50pAmount;
            }
            else
            {
                MessageBox.Show("Masz niewystarczająco punktów!");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timerCount += 1;

            if (timerCount % 2 == 0)
            {
                playerPoints += _50pAmount;
            }

            if (timerCount % 5 == 0)
            {
                playerPoints += _20pAmount;
            }

            if (timerCount % 10 == 0)
            {
                playerPoints += _5pAmount;
            }

            label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
            label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
            label_poluttion.Text = "Poziom zanieczyszczenia: " + pollution.ToString() + " pkt";

        }



        public void button_restart_Click(object sender, EventArgs e)
        {
            //Reset button
            timer1.Stop();
            _ticks = 0;
            if (level == 1)
            {
                playerPoints = 50*2;
                value_ticks = 500;
                pollution = 1500;
                label_points.Text = "Ilość kliknięć: " + playerPoints;
                label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
            }
            if (level == 2)
            {
                playerPoints = 25*2;
                value_ticks = 600;
                pollution = 2000;
                label_points.Text = "Ilość kliknięć: " + playerPoints;
                label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
            }
            if (level == 3)
            {
                playerPoints = 0;
                value_ticks = 800;
                pollution = 2500;
                label_points.Text = "Ilość kliknięć: " + playerPoints;
                label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
            }
            _5pAmount = 0;
            _20pAmount = 0;
            _50pAmount = 0;
            label_ticks.Text = "Czas: 0 s";
            label_coffee.Text = "ilość kawy: " + _5pAmount;
            label_worker.Text = "ilość pracowników " + _20pAmount;
            label_firm.Text = "ilość firm: " + _50pAmount;

        }

        private void COUNTING_TIMER_Tick(object sender, EventArgs e)
        {
            //czasomierz
            _ticks++;
            label_ticks.Text = "Czas: " + _ticks + " s";

            if (_ticks == value_ticks)
            {
                timer1.Stop();
                _ticks = 0;
                playerPoints = 0;
                _5pAmount = 0;
                _20pAmount = 0;
                _50pAmount = 0;
                label_ticks.Text = "Gra skończona";
                //label_points.Text = "Ilość kliknięć: " + playerPoints;
                //label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
                label_coffee.Text = "ilość kawy: " + _5pAmount;
                label_worker.Text = "ilość pracowników " + _20pAmount;
                label_firm.Text = "ilość firm: " + _50pAmount;
                MessageBox.Show("Czas się skończył!");

                switch(GameWindow.instance.level)
                {
                    case 1:
                        //GameWindow.instance.level = 1;
                        playerPoints = 50*2;
                        label_points.Text = "Ilość kliknięć: " + playerPoints;
                        label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
                        break;
                    case 2:
                        //GameWindow.instance.level = 2;
                        playerPoints = 25 * 2;
                        label_points.Text = "Ilość kliknięć: " + playerPoints;
                        label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
                        break;
                    case 3:
                        //GameWindow.instance.level = 3;
                        playerPoints = 0;
                        label_points.Text = "Ilość kliknięć: " + playerPoints;
                        label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
                        break;
                }
            }
        }

        private void button_menu_Click(object sender, EventArgs e)
        {
            GameWindow form_game = this;
            form_game.Hide();

            Menu form_menu = new Menu();
            form_menu.Show();
            button_restart_Click(sender, e);
        }

        private void button_shop_Click(object sender, EventArgs e)
        {
            Shop form_shop = new Shop();
            form_shop.Show();

            timer1.Stop();
            COUNTING_TIMER.Stop();
            GameWindow form_game = this;
            form_game.Hide();
        }

        private void refresh(object sender, EventArgs e)
        {
            label_points.Text = "Ilość kliknięć: " + playerPoints.ToString();
            label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
            label_poluttion.Text = "Poziom zanieczyszczenia: " + pollution.ToString() + " pkt";

            if (GameWindow.instance.level == 1)
            {
                label_goal.Text = "Poziom łatwy: Masz 500 s, aby pozbyć się 1500 pkt zanieczyszczenia";
            }

            if (GameWindow.instance.level == 2)
            {
                label_goal.Text = "Poziom średni: Masz 600 s, aby pozbyć się 2000 pkt zanieczyszczenia";
            }

            if (GameWindow.instance.level == 3)
            {
                label_goal.Text = "Poziom trudny: Masz 800 s, aby pozbyć się 2500 pkt zanieczyszczenia";
            }

            if (pollution <= 0)
            {
                pollution = 0;
                timer1.Stop();
                COUNTING_TIMER.Stop();
                _ticks = 0;
                playerPoints = 0;
                _5pAmount = 0;
                _20pAmount = 0;
                _50pAmount = 0;
                label_ticks.Text = "Gra skończona";
                label_points.Text = "Ilość kliknięć: " + playerPoints;
                label_money.Text = "Ilość pieniędzy: " + playerPoints / 2 + " zł";
                label_coffee.Text = "ilość kawy: " + _5pAmount;
                label_worker.Text = "ilość pracowników " + _20pAmount;
                label_firm.Text = "ilość firm: " + _50pAmount;
                //MessageBox.Show("Wygrałeś! Możesz teraz spróbować inny poziom!");
            }

            //label_goal.Text = "Poziom " + GameWindow.instance.level_name + ": Masz " + _ticks.ToString() + " s, aby pozbyć się " + label_poluttion.ToString() + " pkt zanieczyszczenia";

            //MessageBox.Show("Zmiany"); //test czy działa
        }
    }
}
